import numpy as np

def find_roots(data):
    """
    data: numpy array of shape (n, 2) -> [[x1,y1], [x2,y2], ...]
    
    Returns:
        count: number of roots
        roots: numpy array of root x-values
    """
    x = data[:, 0]
    y = data[:, 1]
    
    roots = []
    
    for i in range(len(x) - 1):
        x1, x2 = x[i], x[i+1]
        y1, y2 = y[i], y[i+1]
        
        # Case 1: exact zero
        if y1 == 0:
            roots.append(x1)
        
        # Case 2: sign change → root between points
        elif y1 * y2 < 0:
            root = x1 - y1 * (x2 - x1) / (y2 - y1)
            roots.append(root)
    
    # Optional: handle last point if exactly zero
    if y[-1] == 0:
        roots.append(x[-1])
    
    return len(roots), np.array(roots)