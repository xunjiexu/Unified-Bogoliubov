

import matplotlib.pyplot as plt
import numpy as np

plt.rc('text', usetex=True)
plt.rc('font', family='serif')
plt.rc('text.latex', preamble=r'\usepackage{wasysym}')


import scipy.integrate as si
import scipy as sp
import scipy.optimize as so
import scipy.interpolate as st #sinterp

Abs=np.abs
Log=np.log
Log10=np.log10
Pi=np.pi
ArcTanh=np.arctanh
Tanh=np.tanh
Sqrt=np.sqrt
Exp=np.exp
Cos=np.cos
Sin=np.sin
Arg=np.angle
BesselK=sp.special.kv
Erf=sp.special.erf
HeavisideTheta=lambda x: np.heaviside(x,0)

def MMA_Gamma(a,z):
    '''The incomplete gamma function defined in Wolfram Mathematica convention, 
    which is also the standard convetion on wikipedia'''
    return sp.special.gamma(a)*(sp.special.gammaincc(a, z))

# def Interpolate(x, xp, fp):
#     '''Almost the same as np.interp, except that is also works with descending xp'''
#     if xp[1]-xp[0]>0:
#         xp_new=xp
#         fp_new=fp
#     else: 
#         xp_new=xp[::-1]
#         fp_new=fp[::-1]
#     assert np.all(np.diff(xp_new) > 0)
    
#     return np.interp(x, xp_new, fp_new)


def Interpolate(x, xp, fp):
    '''Almost the same as np.interp, except that is also works with descending xp'''
    if xp[-1]-xp[0]>0:
        xp_new=xp
        fp_new=fp
    else: 
        xp_new=xp[::-1]
        fp_new=fp[::-1]
    assert np.all(np.diff(xp_new) >= 0)
    
    return np.interp(x, xp_new, fp_new)

def Plot(fun,xminmax,n=100, scale="linear",ax=None):
    if scale=="linear":
        xlist=np.linspace(xminmax[0],xminmax[1],n)
    else:
        xlist=np.geomspace(xminmax[0],xminmax[1],n)
    ylist=[fun(x) for x in xlist]
    
    if ax ==None:
        p=plt
    else:
        p=ax
    p.plot(xlist,ylist)
    if scale=="log":
        p.loglog()
    
import time
def Timing_begin():
    global time_start
    time_start=time.time()
def Timing_end():
    Δt=time.time()-time_start
    print("time used:",Δt)


def Max_pos(L):
    if type(L)==np.ndarray:
        L=L.tolist()
    max_value = max(L)
    max_index = L.index(max_value)
    return max_value,max_index

def get_approx_i(A,a,non_int=False):
    '''for A=[a0,a1,a2,a3,...], return i such that the A_i ≈ a '''
    pos=Interpolate(a,A,np.arange(len(A)))
    if non_int:
        return pos
    return int(pos)

def MMA_str_refine(s, Exp_rep=False,exp_cap=True):# to refine Mathematica output strings
    if "E**" in s and Exp_rep:
        s=s.replace("E**","Exp")
        print("Note: E**(xxx) replaced by Exp(xxx) " )
    if "exp(" in s and exp_cap:
        s=s.replace("exp(","Exp(")
        print("Note: exp(xxx) replaced by Exp(xxx) " )
    rep_list={r"\[Alpha]":"α", r"\[Beta]":"β", r"\[Gamma]":"γ", r"\[Delta]":"δ", r"\[Epsilon]": "ϵ",
            r"\[Zeta]":"ζ",r"\[Eta]":"η",r"\[Theta]":"θ",r"\[Kappa]":"κ", 
            r"\[Lambda]":"λ", r"\[Mu]":"μ",r"\[Nu]":"ν",r"\[Xi]":"ξ",r"\[Pi]":"π",
            r"\[Rho]":"ρ",r"\[Sigma]":"σ", r"\[Tau]":"τ",r"\[Phi]":"ϕ",r"\[Psi]":"ψ",r"\[Omega]":"ω",
            r"\[CapitalGamma]":"Γ",r"\[CapitalLambda]":"Λ",r"\[CapitalOmega]":"Ω"}
    for key in rep_list:
        s=s.replace(key,rep_list[key])
    return s

# Unit={}
def set_unit(unit="GeV=1"):
    global eV, keV, MeV, GeV, TeV, PeV, cm, kpc, Mpc, Gpc, second, Kelvin, mpl, gram, barn, meter,km, erg, GF
    GeV={"GeV=1": 1,"MeV=1":1e3,"keV=1":1e6,"eV=1":1e9,"TeV=1":1e-3}[unit]
    eV, keV, MeV, GeV, TeV, PeV=np.array([1e-9,1e-6,1e-3,1,1e3,1e6])*GeV
    cm=50684.2/eV
    meter=100*cm
    km=1000*meter
    kpc=1.56412e26/eV
    Gpc=1e6*kpc;Mpc=1e3*kpc;
    second=1.5192950470981468e15/eV
    Kelvin=0.00008617 *eV;
    mpl=1.22e19*GeV
    gram=5.61e23 * GeV
    barn=1e-28 * meter**2;
    erg=6.242e11 * eV
    Watt=4108.4843999999985 * (eV**2) 
    GF=1.166e-5/GeV**2;

    Mp=2.43355e18*GeV

    kg=1e3*gram
    Newton=kg*meter/second**2;
    Pa = Newton/meter**2;
    
    #Unit.update(...)
    return {"eV":eV, "keV":keV, "MeV":MeV, "GeV":GeV, "TeV":TeV, "PeV":PeV,"cm":cm,"meter":meter,"km":km,
    "kpc":kpc, "Mpc":Mpc, "Gpc":Gpc, "second":second, "Kelvin":Kelvin, "mpl":mpl, "gram":gram, "barn":barn, "meter":meter,"km":km, "erg":erg, "GF":GF,"Mp":Mp,"Pa":Pa,"Newton":Newton,"Watt":Watt}
        
def set_ax(ax,xylabel=["",""],xyscale=["linear","linear"],xylim=None,legend="off",grid="off"):
    ax.set_xlabel(xylabel[0],fontsize=14)
    ax.set_ylabel(xylabel[1],fontsize=14)
    ax.tick_params(which='both', direction='in')
    ax.set_xscale(xyscale[0])
    ax.set_yscale(xyscale[1])
    if xylim!=None:
        ax.set_xlim(xylim[0])
        ax.set_ylim(xylim[1])
    if legend=="on":
        ax.legend(fontsize=12)
    if grid=="on":
        ax.grid()

# gstar=106.75
# # gH=(8*Pi**3 * gstar /90 ) **0.5
# gBH=7.5e-3 
# gram=5.61e23 * GeV
